package com.dewesoft.ethcatclient;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import javax.swing.JTextArea;

public class DataClient implements Runnable
{

  private boolean   m_isRunning;
  private int       m_receivedData;
  private int       m_maxReceivedData;
  private int       m_packetsReceived;
  private int       m_packetsErrors;

  private JTextArea m_output;

  private String    m_hostName;
  private int       m_portNumber =6666;

  public DataClient(String ip, JTextArea output)
  {
    m_hostName=ip;
    m_output=output;

    m_isRunning=false;
    m_receivedData=0;
    m_maxReceivedData=0;
    m_packetsReceived=0;
    m_packetsErrors=0;
  }

  public void stop()
  {
    m_isRunning=false;
  }

  @Override
  public void run()
  {
    m_isRunning=true;

    try
    {
      Socket socket=new Socket(m_hostName, m_portNumber);

      byte buffPacket[]=new byte[40000];
      int buffEnd=0;

      int firstPacketNumber=-1;
      short lastPacketNumber=-1;

      String headerText="";

      InputStream is=socket.getInputStream();
      DataInputStream dis=new DataInputStream(is);
      while (m_isRunning==true)
      {
        while (is.available()>0)
        {
          byte buffRead[]=new byte[20001];
          int ret=dis.read(buffRead, 0, 20000);

          if (ret>0)
          {
            m_receivedData+=ret;

            headerText="Prejetih podatkov: "+m_receivedData+" (+"+ret+")\n";

            if (ret>m_maxReceivedData)
            {
              m_maxReceivedData=ret;
            }
            headerText+="Maksimalno prejeto: "+m_maxReceivedData+"\n";

            for (int r=0; r<ret; r++, buffEnd++)
            {
              buffPacket[buffEnd]=buffRead[r];
            }

            while (buffEnd>=8)
            {
              m_packetsReceived++;

              int readIndex=0;
              byte byteArray[]=new byte[4];
              byteArray[0]=buffPacket[readIndex];
              byteArray[1]=buffPacket[readIndex+1];
              ByteBuffer bb=ByteBuffer.wrap(byteArray);
              bb.order(ByteOrder.LITTLE_ENDIAN);
              short packetId=0;
              packetId=bb.getShort();
              readIndex+=2;
              // System.out.println("Message ID: "+packetId);

              if (packetId!=21845)
              {
                System.out.println("Message ID: "+packetId);
                m_packetsErrors++;
              }

              byteArray=new byte[4];
              byteArray[0]=buffPacket[readIndex];
              byteArray[1]=buffPacket[readIndex+1];
              bb=ByteBuffer.wrap(byteArray);
              bb.order(ByteOrder.LITTLE_ENDIAN);
              short packetNumber=0;
              packetNumber=bb.getShort();
              readIndex+=2;
              // System.out.println("Message Number: "+packetNumber);
              if (firstPacketNumber==-1)
              {
                firstPacketNumber=packetNumber;
              }

              if (lastPacketNumber!=-1 && packetNumber!=-32768)
              {
                if (lastPacketNumber+1!=packetNumber)
                {
                  System.out.println("Wrong packet number: "+packetNumber+"("
                      +lastPacketNumber+")");
                  m_packetsErrors++;
                }
              }
              lastPacketNumber=packetNumber;

              byteArray=new byte[4];
              byteArray[0]=buffPacket[readIndex];
              byteArray[1]=buffPacket[readIndex+1];
              byteArray[2]=buffPacket[readIndex+2];
              byteArray[3]=buffPacket[readIndex+3];
              bb=ByteBuffer.wrap(byteArray);
              bb.order(ByteOrder.LITTLE_ENDIAN);
              int bodyLength=0;
              bodyLength=bb.getInt();
              readIndex+=4;
              // System.out.println("Body Length: "+bodyLength);

              if (bodyLength<0)
              {
                System.out.println("Body length: "+bodyLength+" ("+packetNumber
                    +")");
                m_packetsErrors++;
              }

              byte packetBody[]=new byte[bodyLength];
              for (int r=0; r<bodyLength; r++)
              {
                packetBody[r]=buffPacket[readIndex];
                readIndex++;
              }

              String contentText="Packets Received: "+m_packetsReceived
                  +"\nPackets Errors: "+m_packetsErrors+"\nPrvi paket: "
                  +firstPacketNumber+"\n\nPacket ID: "+packetId
                  +"\nPacket Num: "+packetNumber+"\nBody Length: "+bodyLength;

              for (int num=0, valNum=1; num<bodyLength; num+=4, valNum++)
              {
                byteArray=new byte[4];
                byteArray[0]=packetBody[num];
                byteArray[1]=packetBody[num+1];
                byteArray[2]=packetBody[num+2];
                byteArray[3]=packetBody[num+3];
                bb=ByteBuffer.wrap(byteArray);
                bb.order(ByteOrder.LITTLE_ENDIAN);
                int value=0;
                value=bb.getInt();
                // System.out.println("Value "+valNum+": "+value);
                contentText+="\nValue "+valNum+": "+value;
              }

              byteArray=new byte[4];
              byteArray[0]=packetBody[2];
              byteArray[1]=packetBody[3];
              bb=ByteBuffer.wrap(byteArray);
              bb.order(ByteOrder.LITTLE_ENDIAN);
              short temperature=0;
              temperature=bb.getShort();

              contentText+="\n\nTemperature: "+temperature;

              m_output.setText(headerText+"\n"+contentText);

              int skopirano=0;
              for (int r=readIndex; r<buffEnd; r++, skopirano++)
              {
                buffPacket[skopirano]=buffPacket[r];
              }
              buffEnd-=readIndex;
            }

          }

        }

        Thread.sleep(100);
      }

      socket.close();
    }
    catch (UnknownHostException e)
    {
      System.err.println("Don't know about DATA host "+m_hostName);
    }
    catch (IOException e)
    {
      System.err.println("Couldn't get DATA I/O for the connection to "
          +m_hostName);
    }
    catch (InterruptedException e)
    {
      System.err.println("Sleep exception");
      e.printStackTrace();
    }
  }

}
