package com.dewesoft.ethcatclient;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class EthcatClient extends JFrame implements ActionListener
{

  private static final long serialVersionUID =-2612540972589120271L;

  private JTextArea         m_prntData;
  private JTextArea         m_prntComm;
  private JComboBox<String> m_commandsServ;
  private JComboBox<String> m_commandsSSH;

  private String            m_serverIp;
  private String            m_serverUsername;
  private String            m_serverPassword;
  private int               m_commandNumber;

  private CommandClient     m_commandClient;
  private DataClient        m_dataClient;

  public EthcatClient(String ip, String username, String password)
  {
    m_serverIp=ip;
    m_serverUsername=username;
    m_serverPassword=password;
    m_commandNumber=1;

    m_dataClient=null;

    setTitle("EthcatClient");
    setSize(600, 600);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);

    JPanel content=(JPanel)getContentPane();
    content.setLayout(new BorderLayout());

    ServerCommandPerformed serverCommandPerformed=new ServerCommandPerformed();
    SSHCommandPerformed sshCommandPerformed=new SSHCommandPerformed();

    // =========SERVER============
    JPanel server=new JPanel();
    server.setLayout(new BoxLayout(server, BoxLayout.Y_AXIS));
    JLabel label=new JLabel("Server");
    label.setFont(new Font("Times New Roman", Font.BOLD, 18));
    label.setAlignmentX(CENTER_ALIGNMENT);
    server.add(label);

    JPanel gumbi=new JPanel(new FlowLayout());
    JButton button=new JButton("Start");
    button.setActionCommand("RTC_START");
    button.addActionListener(serverCommandPerformed);
    gumbi.add(button);
    button=new JButton("Stop");
    button.setActionCommand("RTC_STOP");
    button.addActionListener(serverCommandPerformed);
    gumbi.add(button);
    server.add(gumbi);

    // =========TRANSFER============
    JPanel transfer=new JPanel();
    transfer.setLayout(new BoxLayout(transfer, BoxLayout.Y_AXIS));
    label=new JLabel("Transfer");
    label.setFont(new Font("Times New Roman", Font.BOLD, 18));
    label.setAlignmentX(CENTER_ALIGNMENT);
    transfer.add(label);

    gumbi=new JPanel(new FlowLayout());
    button=new JButton("Start");
    button.setActionCommand("START_TRANSFER");
    button.addActionListener(serverCommandPerformed);
    gumbi.add(button);
    button=new JButton("Stop");
    button.setActionCommand("STOP_TRANSFER");
    button.addActionListener(serverCommandPerformed);
    gumbi.add(button);
    transfer.add(gumbi);

    // =========COMMANDS============
    JPanel commands=new JPanel();
    commands.setLayout(new BoxLayout(commands, BoxLayout.Y_AXIS));
    label=new JLabel("Commands");
    label.setFont(new Font("Times New Roman", Font.BOLD, 18));
    label.setAlignmentX(CENTER_ALIGNMENT);
    commands.add(label);

    JPanel panel1=new JPanel(new BorderLayout());

    String commandsServerList[]= { "RTC_START", "RTC_STOP",
        "START_TRANSFER", "STOP_TRANSFER", "RTC_IS_RUNNING",
        "IS_TRANSFER_RUNNING", "RTC_GET_VERSION", "GET_VERSION", "RTC_PAUSE",
        "PING", "STATUS_TEMPLATE", "TO_FILE" };
    m_commandsServ=new JComboBox<String>(commandsServerList);
    panel1.add(m_commandsServ, BorderLayout.NORTH);

    button=new JButton("Execute Command");
    button.setActionCommand("execComm");
    button.addActionListener(serverCommandPerformed);

    JPanel panel2=new JPanel(new BorderLayout());
    panel2.add(button, BorderLayout.NORTH);
    panel1.add(panel2, BorderLayout.SOUTH);

    commands.add(panel1);

    // =========SSH============
    JPanel ssh=new JPanel();
    ssh.setLayout(new BoxLayout(ssh, BoxLayout.Y_AXIS));
    label=new JLabel("SSH");
    label.setFont(new Font("Times New Roman", Font.BOLD, 18));
    label.setAlignmentX(CENTER_ALIGNMENT);
    ssh.add(label);

    panel1=new JPanel(new BorderLayout());

    String commandsSSHList[]= { "System Info", "List Modules",
        "List Processes", "Print Kernel Buffer" };
    m_commandsSSH=new JComboBox<String>(commandsSSHList);
    panel1.add(m_commandsSSH, BorderLayout.NORTH);

    button=new JButton("Execute SSH");
    button.setActionCommand("execSSH");
    button.addActionListener(sshCommandPerformed);

    panel2=new JPanel(new BorderLayout());
    panel2.add(button, BorderLayout.NORTH);
    panel1.add(panel2, BorderLayout.SOUTH);

    ssh.add(panel1);

    // =========COMMANDS EXITS============
    m_prntComm=new JTextArea();
    JScrollPane scroll=new JScrollPane(m_prntComm);

    // =========LAYOUT============

    JPanel parts=new JPanel(new BorderLayout());

    panel1=new JPanel(new BorderLayout());
    panel1.add(server, BorderLayout.NORTH);
    parts.add(panel1, BorderLayout.CENTER);

    panel2=new JPanel(new BorderLayout());
    panel2.add(transfer, BorderLayout.NORTH);
    panel1.add(panel2, BorderLayout.CENTER);
    panel1=panel2;

    panel2=new JPanel(new BorderLayout());
    panel2.add(new JLabel("  "), BorderLayout.NORTH);
    panel1.add(panel2, BorderLayout.CENTER);
    panel1=panel2;

    panel2=new JPanel(new BorderLayout());
    panel2.add(commands, BorderLayout.NORTH);
    panel1.add(panel2, BorderLayout.CENTER);
    panel1=panel2;

    panel2=new JPanel(new BorderLayout());
    panel2.add(new JLabel("  "), BorderLayout.NORTH);
    panel1.add(panel2, BorderLayout.CENTER);
    panel1=panel2;

    panel2=new JPanel(new BorderLayout());
    panel2.add(ssh, BorderLayout.NORTH);
    panel1.add(panel2, BorderLayout.CENTER);
    panel1=panel2;

    panel2=new JPanel(new BorderLayout());
    panel2.add(new JLabel("  "), BorderLayout.NORTH);
    panel1.add(panel2, BorderLayout.CENTER);
    panel1=panel2;

    panel2=new JPanel(new BorderLayout());
    panel2.add(scroll, BorderLayout.CENTER);
    panel1.add(panel2, BorderLayout.CENTER);
    panel1=panel2;

    content.add(parts, BorderLayout.WEST);

    // =====================
    m_prntData=new JTextArea();
    scroll=new JScrollPane(m_prntData);
    content.add(scroll, BorderLayout.CENTER);

    // =====================
    button=new JButton("Exit");
    button.setActionCommand("exit");
    button.addActionListener(this);
    content.add(button, BorderLayout.SOUTH);

    setVisible(true);

    m_commandClient=new CommandClient(m_serverIp);
  }

  private class ServerCommandPerformed implements ActionListener
  {

    @Override
    public void actionPerformed(ActionEvent e)
    {
      String command=e.getActionCommand();

      if (command.equals("execComm")==true)
      {
        command=(String)m_commandsServ.getSelectedItem();
      }

      String response=m_commandClient.sendCommand(command);
      String text=m_prntComm.getText()+m_commandNumber+": "+command+" -> "
          +response+"\n";
      m_prntComm.setText(text);
      m_commandNumber++;

      if (command.equals("START_TRANSFER")==true)
      {
        if (m_dataClient==null)
        {
          m_dataClient=new DataClient(m_serverIp, m_prntData);

          (new Thread(m_dataClient)).start();
        }
      }
      else if (command.equals("STOP_TRANSFER")==true)
      {
        if (m_dataClient!=null)
        {
          m_dataClient.stop();
          m_dataClient=null;
        }
      }
    }

  }

  private class SSHCommandPerformed implements ActionListener
  {

    @Override
    public void actionPerformed(ActionEvent e)
    {
      String command=e.getActionCommand();

      if (command.equals("execSSH")==true)
      {
        String sshAction=(String)m_commandsSSH.getSelectedItem();
        String text=m_prntComm.getText()+m_commandNumber+": SSH "+sshAction
            +"\n";
        m_prntComm.setText(text);
        m_commandNumber++;

        String sshCommand="ls -al";
        switch (m_commandsSSH.getSelectedIndex())
        {
        case 0:
          sshCommand="uname -a";
          break;
        case 1:
          sshCommand="lsmod";
          break;
        case 2:
          sshCommand="ps aux";
          break;
        case 3:
          sshCommand="dmesg";
          break;
        }

        SSHClient sshClient=new SSHClient(m_serverIp, m_serverUsername,
            m_serverPassword, m_prntData);
        sshClient.open();
        sshClient.execCommand(sshCommand);
        sshClient.close();
      }

    }

  }

  @Override
  public void actionPerformed(ActionEvent e)
  {
    String action=e.getActionCommand();
    if (action.equals("exit")==true)
    {
      if (m_dataClient!=null)
      {
        m_dataClient.stop();
      }

      dispose();
    }
  }

  public static void main(String args[])
  {
    System.out.println("Execute:");
    System.out.println("java -jar JavaTestClient <IP> <USER> <PASS>");
    System.out.println("<IP>   - host address");
    System.out.println("<USER> - username to connect on SSH");
    System.out.println("<PASS> - password for SSH access");

    if (args.length==1)
    {
      new EthcatClient(args[0], "", "");
    }
    else if (args.length==1)
    {
      new EthcatClient(args[0], args[1], args[2]);
    }
    else
    {
      new EthcatClient("164.8.230.246", "root", "catertest");
    }
  }

}
