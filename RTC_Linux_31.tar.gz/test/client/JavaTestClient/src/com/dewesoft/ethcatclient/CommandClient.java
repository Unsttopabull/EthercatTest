package com.dewesoft.ethcatclient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class CommandClient
{

  private String m_hostName;
  private int    m_portNumber=5555;

  public CommandClient(String ip)
  {
    m_hostName=ip;
  }

  public String sendCommand(String command)
  {
    String izhod="---";
    try
    {
      Socket socket=new Socket(m_hostName, m_portNumber);
      PrintWriter out=new PrintWriter(socket.getOutputStream(), true);
      BufferedReader in=new BufferedReader(new InputStreamReader(
          socket.getInputStream()));

      out.println(command);
      izhod=in.readLine();

      socket.close();
    }
    catch (UnknownHostException e)
    {
      System.err.println("Don't know about host "+m_hostName);
      System.exit(1);
    }
    catch (IOException e)
    {
      System.err.println("Couldn't get I/O for the connection to "+m_hostName);
      System.exit(1);
    }

    return izhod;
  }

}
