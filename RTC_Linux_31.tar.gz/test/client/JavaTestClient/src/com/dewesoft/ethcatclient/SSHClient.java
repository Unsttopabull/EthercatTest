package com.dewesoft.ethcatclient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.swing.JTextArea;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.UIKeyboardInteractive;
import com.jcraft.jsch.UserInfo;

public class SSHClient
{

  private Session   m_session;

  private JTextArea m_output;

  private String    m_hostName;
  private String    m_userName;
  private String    m_userPassword;

  public SSHClient(String ip, String userName, String password,  JTextArea output)
  {
    m_hostName=ip;
    m_userName=userName;
    m_userPassword=password;
    m_output=output;

    m_session=null;
  }

  public void open()
  {
    try
    {
      JSch jsch=new JSch();

      m_session=jsch.getSession(m_userName, m_hostName, 22);
      m_session.setPassword(m_userPassword);
      m_session.setUserInfo(new MyUserInfo());
      m_session.connect(30000); // making a connection with timeout.
    }
    catch (Exception e)
    {
      System.out.println("Connection problems.");
      // e.printStackTrace();
      m_output.setText("Connection problems.\n"+e.toString());
      m_session=null;
    }
  }

  public void close()
  {
    if (m_session!=null)
    {
      try
      {
        m_session.disconnect();
        m_session=null;
      }
      catch (Exception e)
      {
        System.out.println(e);
      }
    }
  }

  public void execCommand(String command)
  {
    String text="Executing:\n"+command+"\n\nResponse:\n";

    if (m_session!=null)
    {
      try
      {
        Channel channel=m_session.openChannel("exec");
        ((ChannelExec)channel).setCommand(command);
        channel.setInputStream(null);
        ((ChannelExec)channel).setErrStream(System.err);

        InputStream in=channel.getInputStream();
        channel.connect();

        BufferedReader br=new BufferedReader(new InputStreamReader(in));

        String line;
        while ((line=br.readLine())!=null)
        {
          text+=line+"\n";
        }

        // System.out.println("exit-status: "+channel.getExitStatus());
        channel.disconnect();
      }
      catch (JSchException e)
      {
        System.out.println("Execute problems.");
        // e.printStackTrace();
        text="Execute problems.\n"+e.toString();
      }
      catch (IOException e)
      {
        System.out.println("Execute problems.");
        // e.printStackTrace();
        text="Execute problems.\n"+e.toString();
      }
      
      m_output.setText(text);
    }

  }

  private class MyUserInfo implements UserInfo, UIKeyboardInteractive
  {
    public String getPassword()
    {
      return null;
    }

    public boolean promptYesNo(String str)
    {
      return true;
    }

    public String getPassphrase()
    {
      return null;
    }

    public boolean promptPassphrase(String message)
    {
      return false;
    }

    public boolean promptPassword(String message)
    {
      return false;
    }

    public void showMessage(String message)
    {
    }

    public String[] promptKeyboardInteractive(String destination, String name,
        String instruction, String[] prompt, boolean[] echo)
    {
      return null;
    }
  }

}
