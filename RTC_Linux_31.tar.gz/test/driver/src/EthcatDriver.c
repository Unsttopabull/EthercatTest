#include <linux/module.h>
#include <linux/kernel.h>

#include <linux/fs.h>                 // za nastavitev toka
#include <linux/device.h>             // za prijavo gonilnika 
#include <linux/cdev.h>

#include <linux/uaccess.h>            // branje in pisanje podatkov uporabnika
#include <linux/slab.h>               // kmalloc
#include <linux/kthread.h>
#include <linux/delay.h>

#include <linux/init.h>

#include "CommandListener.h"


#define DRIVER_VERSION   "0.0.0.1"

#define DATA_BUFFER_SIZE    1048576
#define SEQUENCER_DATA_SIZE 1048576

#define PACKET_ID 21845
#define PACKET_BODY_VALUES 5
#define TRAFFIC_GENERATE_SLEEP 1

static dev_t first;       // Global variable for the first device number
static struct cdev c_dev; // Global variable for the character device structure
static struct class *cl;  // Global variable for the device class

char ethcatData[DATA_BUFFER_SIZE];
int indexWriter=0;
int indexReader=0;
unsigned int measureNumber=0;

struct mutex mutexIndexWriter;
struct mutex mutexIsGeneratorRunning;

int isGeneratorRunning=0;

int sampleRate=1000;


char sequencerData[SEQUENCER_DATA_SIZE];
int sequencerDataOffset=0;
int sequencerDataLength=0;



/////////////////////
// MODULE PARAMETERS
/////////////////////

char *driverVersion=DRIVER_VERSION;
module_param_named(version, driverVersion, charp, S_IRUGO);
MODULE_PARM_DESC(version, "EthercatDriver version");

module_param_named(sr, sampleRate, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(sr, "Sample rate");



int trafficGeneratorAlphabet(void *data)
{
  int packetId=PACKET_ID;
  char packet[100];
  int packetLength=0;
  int bodyLength=0;
  int lengthRemaining=0;
  int currentIsGeneratorRunning=0;

  char testData='a';
  char dataValue;
  int l;

  printk(KERN_INFO "ETHCAT_DRIVER: Start generating traffic (Alphabet)\n");

  mutex_lock(&mutexIsGeneratorRunning);
  currentIsGeneratorRunning=isGeneratorRunning;
  mutex_unlock(&mutexIsGeneratorRunning);

  //while(!kthread_should_stop())
  while (currentIsGeneratorRunning!=0)
  {
    dataValue=testData;

    // -------- PACKET HEADER ----------
    bodyLength='z'-dataValue+1;

    memcpy(packet, &packetId, 2);
    packetLength=2;
    memcpy(packet+packetLength, &measureNumber, 2);
    packetLength+=2;
    memcpy(packet+packetLength, &bodyLength, 4);
    packetLength+=4;

    // -------- PACKET BODY ----------
    for (l=0; l<bodyLength; l++)
    {
      packet[packetLength]=dataValue;
      packetLength++;
      dataValue++;
    }

    // -------- SAVE PACKET ----------
    mutex_lock(&mutexIndexWriter);
    lengthRemaining=DATA_BUFFER_SIZE-indexWriter;
    if (lengthRemaining>packetLength)
    {
      memcpy(ethcatData+indexWriter, packet, packetLength);
      indexWriter+=packetLength;
    }
    else if (lengthRemaining<packetLength)
    {
      memcpy(ethcatData+indexWriter, packet, lengthRemaining);
      indexWriter=packetLength-lengthRemaining;
      memcpy(ethcatData, packet+lengthRemaining, indexWriter);
    }
    else // lengthRemaining==packetLength
    {
      memcpy(ethcatData+indexWriter, packet, packetLength);
      indexWriter=0;
    }
    mutex_unlock(&mutexIndexWriter);

    testData++;
    if (testData>'z')
    {
      testData='a';
    }

    measureNumber++;
    if (measureNumber>127)
    {
      measureNumber=0;
    }

    mutex_lock(&mutexIsGeneratorRunning);
    currentIsGeneratorRunning=isGeneratorRunning;
    mutex_unlock(&mutexIsGeneratorRunning);

    msleep(TRAFFIC_GENERATE_SLEEP);
  }

  printk(KERN_INFO "ETHCAT_DRIVER: Stop generating traffic (Alphabet)\n");

  return 0;
}

int trafficGeneratorCurve(void *data)
{
  int packetId=PACKET_ID;
  char packet[1000];
  int packetLength=0;
  unsigned int bodyLength=0;
  int lengthRemaining=0;
  int currentIsGeneratorRunning=0;

  int bodyYValues=PACKET_BODY_VALUES-1;
  int step=1;
  int repeat=1;
  int fx=0;
  int x=0;
  int y=0;

  printk(KERN_INFO "ETHCAT_DRIVER: Start generating traffic (Curve)\n");

  mutex_lock(&mutexIsGeneratorRunning);
  currentIsGeneratorRunning=isGeneratorRunning;
  mutex_unlock(&mutexIsGeneratorRunning);

  //while(!kthread_should_stop())
  while (currentIsGeneratorRunning!=0)
  {
    bodyYValues=PACKET_BODY_VALUES-1;

    // -------- PACKET HEADER ----------
    bodyLength=PACKET_BODY_VALUES*4; // 5 x int values

    memcpy(packet, &packetId, 2);
    packetLength=2;
    memcpy(packet+packetLength, &measureNumber, 2);
    packetLength+=2;
    memcpy(packet+packetLength, &bodyLength, 4);
    packetLength+=4;

    // -------- PACKET BODY ----------
    memcpy(packet+packetLength, &x, 4);
    packetLength+=4;

    while (bodyYValues>0)
    {
      y=fx*bodyYValues*repeat;
      memcpy(packet+packetLength, &y, 4);
      packetLength+=4;

      bodyYValues--;
    }

    // -------- SAVE PACKET ----------
    mutex_lock(&mutexIndexWriter);
    lengthRemaining=DATA_BUFFER_SIZE-indexWriter;
    if (lengthRemaining>packetLength)
    {
      memcpy(ethcatData+indexWriter, packet, packetLength);
      indexWriter+=packetLength;
    }
    else if (lengthRemaining<packetLength)
    {
      memcpy(ethcatData+indexWriter, packet, lengthRemaining);
      indexWriter=packetLength-lengthRemaining;
      memcpy(ethcatData, packet+lengthRemaining, indexWriter);
    }
    else // lengthRemaining==packetLength
    {
      memcpy(ethcatData+indexWriter, packet, packetLength);
      indexWriter=0;
    }
    mutex_unlock(&mutexIndexWriter);

    x++;
    if (x%5000==0)
    {
//      x=0;
      repeat++;
      if (repeat>10)
        repeat=1;
    }

    fx+=step;
    if (fx==10)
    {
      step=-1;
    }
    else if (fx<=-10)
    {
      step=1;
    }

    measureNumber++;

    mutex_lock(&mutexIsGeneratorRunning);
    currentIsGeneratorRunning=isGeneratorRunning;
    mutex_unlock(&mutexIsGeneratorRunning);

    //msleep(100);
    //msleep(10);
    msleep(TRAFFIC_GENERATE_SLEEP);
  }

  printk(KERN_INFO "ETHCAT_DRIVER: Stop generating traffic (Curve)\n");

  return 0;
}

void startMeasuring(void)
{
  //  printk(KERN_INFO "ETHCAT_DRIVER: Start measuring\n");
  int currentIsGeneratorRunning=0;
  struct task_struct *task;

  mutex_lock(&mutexIsGeneratorRunning);
  currentIsGeneratorRunning=isGeneratorRunning;
  mutex_unlock(&mutexIsGeneratorRunning);

  if (currentIsGeneratorRunning==0)
  {
    mutex_lock(&mutexIsGeneratorRunning);
    isGeneratorRunning=1;
    mutex_unlock(&mutexIsGeneratorRunning);

    //task=kthread_run(&trafficGeneratorAlphabet, NULL, "TrafficGeneratorAB");
    task=kthread_run(&trafficGeneratorCurve, NULL, "TrafficGeneratorXY");
  }
}

void stopMeasuring(void)
{
  //  printk(KERN_INFO "ETHCAT_DRIVER: Stop measuring\n");
  mutex_lock(&mutexIsGeneratorRunning);
  if (isGeneratorRunning==1)
  {
    isGeneratorRunning=0;
    //kthread_stop(task);
  }
  mutex_unlock(&mutexIsGeneratorRunning);
}

void resetDriver(void)
{
  //  printk(KERN_INFO "ETHCAT_DRIVER: Reset driver\n");
  // stop generator
  mutex_lock(&mutexIsGeneratorRunning);
  isGeneratorRunning=0;
  mutex_unlock(&mutexIsGeneratorRunning);

  msleep(10);

  mutex_lock(&mutexIndexWriter);
  indexWriter=0;
  indexReader=0;
  measureNumber=0;
  mutex_unlock(&mutexIndexWriter);
}


/////////////////////
// MODULE BUS (command and sequencer)
/////////////////////

struct bus_type ethcatDriverBus=
{
  .name="ethcat",
};

ssize_t busCommandRead(struct bus_type *bus, char *buf)
{
  printk(KERN_INFO "ETHCAT_DRIVER: bus command read\n");

  return scnprintf(buf, PAGE_SIZE, "Supported commands: START, STOP, ...\n");
}

ssize_t busCommandWrite(struct bus_type *bus, const char *buf, size_t len)
{
  char commandStr[50];
long offset;
long length;

  //printk(KERN_INFO "ETHCAT_DRIVER: bus command write: %s\n", commandStr);

  memcpy(commandStr, buf, len);
  commandStr[len]='\0';

  if (isDriverCommand(commandStr,RTC_START)==1)
  {
    startMeasuring();
  }
  else if (isDriverCommand(commandStr,RTC_STOP)==1)
  {
    stopMeasuring();
  }
  else if (isDriverCommand(commandStr,RTC_RESET)==1)
  {
    resetDriver();
  }
  else if (isDriverCommand(commandStr,RTC_IS_RUNNING)==1)
  {
    printk(KERN_INFO "+ERR COMMAND RTC_IS_RUNNING NOT SUPPORTED\r\n");
  }
  else if (isDriverCommand(commandStr,RTC_GET_VERSION)==1)
  {
    printk(KERN_INFO "+ERR COMMAND RTC_GET_VERSION NOT SUPPORTED\r\n");
  }
  else if (isDriverCommand(commandStr, RTC_COMMAND)==1)
  {
    printk(KERN_INFO "RTC_COMMAND: %s\r\n", commandStr);
  }
  else if (isDriverCommand(commandStr, RTC_MEM_OFFSET)==1)
  {
    if (kstrtol(commandStr+15, 10, &offset)==0)
    {
      sequencerDataOffset=(int)offset;
printk(KERN_INFO "RTC_MEM_OFFSET OK\r\n");
    }
    else
    {
printk(KERN_INFO "RTC_MEM_OFFSET NOK!!!!!!!!!!!!!\r\n");
    }
printk(KERN_INFO "RTC_MEM_OFFSET: %d\r\n", sequencerDataOffset);
  }
  else if (isDriverCommand(commandStr, RTC_MEM_LENGTH)==1)
  {
    if (kstrtol(commandStr+15, 10, &length)==0)
    {
      sequencerDataLength=(int)length;
printk(KERN_INFO "RTC_MEM_LENGTH OK\r\n");
    }
    else
    {
printk(KERN_INFO "RTC_MEM_LENGTH NOK!!!!!!!!!!!!!\r\n");
    }
printk(KERN_INFO "RTC_MEM_LENGTH: %d\r\n", sequencerDataLength);
  }
  else
  {
    printk(KERN_INFO "+ERR COMMAND NOT SUPPORTED: %s\r\n", commandStr);
  }

  return len;
}


BUS_ATTR(commandData, S_IRUGO | S_IWUSR, busCommandRead, busCommandWrite);


ssize_t busSeqDataRead(struct bus_type *bus, char *buf)
{
  printk(KERN_INFO "ETHCAT_DRIVER: bus requencer data read\n");

printk(KERN_INFO "offset: %d, length: %d\r\n", sequencerDataOffset, sequencerDataLength);

  memcpy(buf, sequencerData+sequencerDataOffset, sequencerDataLength);

  return sequencerDataLength;
}

ssize_t busSeqDataWrite(struct bus_type *bus, const char *buf, size_t len)
{
  printk(KERN_INFO "ETHCAT_DRIVER: bus sequencer data write\n");

  memcpy(sequencerData+sequencerDataOffset, buf, len);

  return len;
}

BUS_ATTR(sequencerData, S_IRUGO | S_IWUSR, busSeqDataRead, busSeqDataWrite);



/////////////////////
// MODULE DEVICE
/////////////////////


static int deviceDataOpen(struct inode *i, struct file *f)
{
  //printk(KERN_INFO "ETHCAT_DRIVER: device open\n");

  return 0;
}

static int deviceDataClose(struct inode *i, struct file *f)
{
  //printk(KERN_INFO "ETHRECAT_DRIVER: device close\n");

  return 0;
}

static ssize_t deviceDataRead(struct file *f, char __user *buf, size_t len, loff_t *off)
{
  int sizeToRead=0;
  int currentIndexWriter=0;

  //printk(KERN_INFO "ETHCAT_DRIVER: device read\n");

  mutex_lock(&mutexIndexWriter);
  currentIndexWriter=indexWriter;
  mutex_unlock(&mutexIndexWriter);

  if (currentIndexWriter>indexReader)
  {
    sizeToRead=currentIndexWriter-indexReader;
    if (copy_to_user(buf, ethcatData+indexReader, sizeToRead)!=0)
      return -EFAULT;
  }
  else if (currentIndexWriter!=indexReader)
  { // start reading from the beginig of the table
    sizeToRead=DATA_BUFFER_SIZE-indexReader;
    if (copy_to_user(buf, ethcatData+indexReader, sizeToRead)!=0)
      return -EFAULT;
    if (copy_to_user(buf+sizeToRead, ethcatData, currentIndexWriter)!=0)
      return -EFAULT;
    sizeToRead+=currentIndexWriter;
  }
  indexReader=currentIndexWriter;

  return sizeToRead;
}

static ssize_t deviceDataWrite(struct file *f, const char __user *buf, size_t len, loff_t *off)
{
  printk(KERN_INFO "ETHCAT_DRIVER: device write\n");

  return len;
}

static struct file_operations pugs_fops=
{
  .owner=THIS_MODULE,
  .open=deviceDataOpen,
  .release=deviceDataClose,
  .read=deviceDataRead,
  .write=deviceDataWrite
};


/////////////////////
// MODULE init AND exit
/////////////////////


static int __init ethcat_drive_init(void) /* Constructor */
{
  int ret=-1;

int length=0;
int z;
z='A';
for (length=0; length<SEQUENCER_DATA_SIZE; length++)
{
  sequencerData[length]=(char)z;
  z++;
  if (z>'Z')
    z='A';
}

sequencerDataOffset=5;
sequencerDataLength=30;



  printk(KERN_INFO "ETHCAT_DRIVER: Registered\n");

  isGeneratorRunning=0;

  mutex_init(&mutexIndexWriter);
  mutex_init(&mutexIsGeneratorRunning);


  //
  // DEVICE
  //

  if (alloc_chrdev_region(&first, 0, 1, "ethcat")<0)
  {
    printk(KERN_ALERT "ETHCAT_DRIVER: Device Registration failed\n");
    return -1;
  }

  if ((cl=class_create(THIS_MODULE, "ethcatdrv"))==NULL)
  {
    printk(KERN_ALERT "ETHCAT_DRIVER: Class creation failed\n");
    unregister_chrdev_region(first, 1);
    return -1;
  }

  if (device_create(cl, NULL, first, NULL, "ethcat")==NULL)
  {
    printk(KERN_ALERT "ETHCAT_DRIVER: Device creation failed\n");
    class_destroy(cl);
    unregister_chrdev_region(first, 1);
    return -1;
  }

  cdev_init(&c_dev, &pugs_fops);
  if (cdev_add(&c_dev, first, 1)==-1)
  {
    printk(KERN_ALERT "ETHCAT_DRIVER: Device addition failed\n");
    device_destroy(cl, first);
    class_destroy(cl);
    unregister_chrdev_region(first, 1);
    return -1;
  }

  //
  // BUS
  //

  ret=bus_register(&ethcatDriverBus);
  if (ret<0)
  {
    printk(KERN_ALERT "ETHCAT_DRIVER: Error register bus: %d\n", ret);
    return ret;
  }

  ret=bus_create_file(&ethcatDriverBus, &bus_attr_commandData);
  if (ret<0)
  {
    printk(KERN_ALERT "ETHCAT_DRIVER: Error creating busfile (command)\n");
    bus_unregister(&ethcatDriverBus);
    return ret;
  }


/*
  ret=bus_register(&ethcatDriverBus);
  if (ret<0)
  {
    printk(KERN_ALERT "ETHCAT_DRIVER: Error register bus: %d\n", ret);
    return ret;
  }
*/

  ret=bus_create_file(&ethcatDriverBus, &bus_attr_sequencerData);
  if (ret<0)
  {
    printk(KERN_ALERT "ETHCAT_DRIVER: Error creating busfile (sequencer)\n");
    bus_unregister(&ethcatDriverBus);
    return ret;
  }

  return 0;
}

static void __exit ethcat_drive_exit(void) /* Destructor */
{
  //
  // DEVICE
  //
  cdev_del(&c_dev);
  device_destroy(cl, first);
  class_destroy(cl);
  unregister_chrdev_region(first, 1);

  //
  // BUS
  //
  bus_remove_file(&ethcatDriverBus, &bus_attr_commandData);
  bus_remove_file(&ethcatDriverBus, &bus_attr_sequencerData);
  bus_unregister(&ethcatDriverBus);

  printk(KERN_INFO "ETHCAT_DRIVER: Unregistered\n");
}

module_init( ethcat_drive_init);
module_exit( ethcat_drive_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("DeweSoft");
MODULE_DESCRIPTION("EtherCat Driver");

