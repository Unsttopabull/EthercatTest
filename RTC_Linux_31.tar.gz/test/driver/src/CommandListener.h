#ifndef COMMAND_LISTENER
#define COMMAND_LISTENER


#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/device.h>


/////////////////////
// COMMANDS
/////////////////////

typedef enum
{
  RTC_START,
  RTC_STOP,
  RTC_RESET,
  RTC_IS_RUNNING,
  RTC_GET_VERSION,
  RTC_COMMAND,
  RTC_MEM_OFFSET,
  RTC_MEM_LENGTH
} driver_deamon_commands_t;


inline char *commands_to_string(driver_deamon_commands_t s);
int isDriverCommand(char *commandStr, driver_deamon_commands_t s);


#endif
