
#include "CommandListener.h"


/////////////////////
// COMMANDS
/////////////////////

inline char *commands_to_string(driver_deamon_commands_t s)
{
  static char *strings[]=
  {
  "RTC_START",
  "RTC_STOP",
  "RTC_RESET",
  "RTC_IS_RUNNING",
  "RTC_GET_VERSION",
  "RTC_COMMAND",
  "RTC_MEM_OFFSET",
  "RTC_MEM_LENGTH"
  };
  return strings[s];
}

int isDriverCommand(char *commandStr, driver_deamon_commands_t s)
{
  if (strncmp(commandStr, commands_to_string(s), strlen(commands_to_string(s)))==0)
    return 1;
  else
    return 0;
}

