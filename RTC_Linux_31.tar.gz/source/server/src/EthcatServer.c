#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>     // threads
#include <unistd.h>      // usleep

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>



#define DEAMON_VERSION      "0.0.0.1"

#define DATA_BUFFER_SIZE    1048576  // size of data buffer
#define NUM_BUFFERS_TO_FILE 100      // how many MeasureData are in one file

#define COMMAND_PORT_NUMBER   5555
#define DATA_PORT_NUMBER      6666
#define BROADCAST_PORT_NUMBER 7777

#define MESSAGE_ID   21845


pthread_mutex_t mutexDataSize=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutexServerState=PTHREAD_MUTEX_INITIALIZER;

struct MeasureData // data buffer
{
  int id;
  int size;
  char data[DATA_BUFFER_SIZE];
  void *next;
};

struct MeasureData *first=NULL;        // first buffer
struct MeasureData *last=NULL;         // last buffer
struct MeasureData *reading=NULL;      // buffer that is sent

int serverState=0;                     // server state

int isRtcRunning=0;                    // RTC (driver) state

int dataSocket;                        // data connection


int indexReader=0;

/////////////////////
// COMMANDS
/////////////////////
typedef enum
{
  RTC_START,
  START_TRANSFER,
  RTC_STOP,
  STOP_TRANSFER,
  RTC_IS_RUNNING,
  IS_TRANSFER_RUNNING,
  RTC_GET_VERSION,
  GET_VERSION,
  PING,
  RTC_COMMAND,
  RTC_GET_MEM,
  RTC_SET_MEM,
  TO_FILE,
  STOP_SERVER
} server_client_commands_t;

char* commands_to_string(server_client_commands_t s)
{
  static char* strings[]=
  {
  "RTC_START",
  "START_TRANSFER",
  "RTC_STOP",
  "STOP_TRANSFER",
  "RTC_IS_RUNNING",
  "IS_TRANSFER_RUNNING",
  "RTC_GET_VERSION",
  "GET_VERSION",
  "PING",
  "RTC_COMMAND",
  "RTC_GET_MEM",
  "RTC_SET_MEM",
  "TO_FILE",
  "STOP_SERVER"
  };
  return strings[s];
}

int isServerCommand(char *commandStr,server_client_commands_t s){
      if (strncmp(commandStr, commands_to_string(s), strlen(commands_to_string(s)))==0)
          return 1;
      else
          return 0;
}

char* ok_responses_to_string(server_client_commands_t s)
{
  static char* strings[]=
  {
  "OK\r\n",
  "OK\r\n",
  "OK\r\n",
  "OK\r\n",
  "OK YES\r\n",
  "OK YES\r\n",
  "OK 0.0.0.1\r\n",
  "OK 0.0.0.1\r\n",
  "OK PONG\r\n",
  "", //"RTC_COMMAND", not implemented
  "", //"RTC_GET_MEM", not implemented
  "", //"RTC_SET_MEM", not implemented
  "TO_FILE"
  "OK\r\n"
  };
  return strings[s];
}

int ok_response_length(server_client_commands_t s){
  return strlen(ok_responses_to_string(s));
}

char* err_responses_to_string(server_client_commands_t s)
{
  static char* strings[]=
  {
  "+ERR \r\n",
  "+ERR Transfer is already running",
  "OK\r\n",
  "+ERR\r\n",
  "OK NO\r\n",
  "OK NO\r\n",
  "+ERR \r\n",
  "+ERR \r\n",
  "+ERR \r\n",
  "+ERR Not implemented\r\n",
  "+ERR Not implemented\r\n",
  "+ERR Not implemented\r\n",
  "+ERR \r\n",
  "+ERR \r\n"
  };
  return strings[s];
}

int err_response_length(server_client_commands_t s){
  return strlen(err_responses_to_string(s));
}

void resetEthercatDriver(void);

int initCommandServer(void);
int initDataServer(void);

void stopCommandServer(void);
void stopDataServer(void);

void* runCommandServer(void *args);
void* runDataServer(void *args);

void readDataFromDriver(void);
void sendEthercatDriverCommand(char *command);

void getNewMeasureDataSpace(void);
void* writeMeasureDataToFile(void *args);


void resetEthercatDriver(void)
{
  sendEthercatDriverCommand("RTC_RESET");

  usleep(100000);

  // remove all old data
  FILE *ifStream=fopen("/dev/ethcat", "r");
  if (ifStream==NULL)
  {
    printf("ETHCAT_SERVER: Error while opening the driver data.\n");
    return;
  }

  int oldData=0;
  int ch;
  while ((ch=fgetc(ifStream))!=EOF)
  {
    oldData++;
  }

  fclose(ifStream);
}

// initialize command connection and start listening
int initCommandServer(void)
{
  pthread_t tid;
  int err=pthread_create(&tid, NULL, &runCommandServer, NULL);
  if (err!=0)
  {
    return -1;
  }

  return 0;
}

// initialize connection for data transfer
int initDataServer(void)
{
  struct sockaddr_in serverAddr;

  dataSocket=socket(AF_INET, SOCK_STREAM, 0);
  if (dataSocket<0)
  {
    printf("ETHCAT_SERVER: Error opening DATA socket.\n");
  }
  bzero((char*) &serverAddr, sizeof(serverAddr));
  serverAddr.sin_family=AF_INET;
  serverAddr.sin_addr.s_addr=INADDR_ANY;
  serverAddr.sin_port=htons(DATA_PORT_NUMBER);
  if (bind(dataSocket, (struct sockaddr *) &serverAddr, sizeof(serverAddr))<0)
  {
    printf("ETHCAT_SERVER: Error on DATA binding.\n");
  }

  listen(dataSocket, 5);

  return 0;
}




int getMemoryData(char *memData)
{
  int returnedSize=0;

  FILE *ifStream;
  ifStream=fopen("/sys/bus/ethcat/sequencerData", "r");
  if (ifStream==NULL)
  {
    printf("ETHCAT_SERVER: Error opening sequencer bus data.\n");
  }

  int ch;
  while ((ch=fgetc(ifStream))!=EOF)
  {
    memData[returnedSize]=ch;
    returnedSize++;
  } // while there are data available

  fclose(ifStream);

  return returnedSize;
}


/*
int setMemoryData(char *memData)
{
  int returnedSize=0;

  FILE *ofStream;
  ofStream=fopen("/sys/bus/ethcat/sequencerData", "w");
  if (ofStream==NULL)
  {
    printf("ETHCAT_SERVER: Error opening sequencer bus data.\n");
  }

  int size
  int ch;
  for (returnedSize=0; returnedSize<strlen(memData), returnedSize++)
  {
    fputc(memData+ch, ofStream);
  }

  fclose(ofStream);

  return returnedSize;
}
*/


int setMemoryData(char *memData)
{
  FILE *ofStream=fopen("/sys/bus/ethcat/sequencerData", "w");
  fprintf(ofStream, "%s", memData);
  fclose(ofStream);

  return strlen(memData);
}


void* runCommandServer(void *args)
{
  int currentServerState=0;

  struct sockaddr_in serverAddr;
  struct sockaddr_in clientAddr;

  int commandSocket;

  socklen_t clilen;
  char buffer[256];

  int n;
  commandSocket=socket(AF_INET, SOCK_STREAM, 0);
  if (commandSocket<0)
  {
    printf("ETHCAT_SERVER: Error opening COMMAND socket.\n");
  }
  bzero((char*) &serverAddr, sizeof(serverAddr));
  serverAddr.sin_family=AF_INET;
  serverAddr.sin_addr.s_addr=INADDR_ANY;
  serverAddr.sin_port=htons(COMMAND_PORT_NUMBER);
  if (bind(commandSocket, (struct sockaddr *) &serverAddr, sizeof(serverAddr))<0)
  {
    printf("ETHCAT_SERVER: Error on COMMAND binding.\n");
  }

  listen(commandSocket, 5);
  clilen=sizeof(clientAddr);

  int newsockfd=0;
  //while (1)
  while (currentServerState!=-1)
  {
    pthread_mutex_lock(&mutexServerState);
    currentServerState=serverState;
    pthread_mutex_unlock(&mutexServerState);

    newsockfd=accept(commandSocket, (struct sockaddr *) &clientAddr, &clilen);
    if (newsockfd<0)
    {
      printf("ETHCAT_SERVER: Error on COMMAND accept.\n");
    }

    n=read(newsockfd, buffer, 255);
    if (n<0)
    {
      printf("ETHCAT_SERVER: Error reading from COMMAND socket.\n");
    }
    buffer[n]='\0';

    //printf("Command: %s\n", buffer);

    if (isServerCommand(buffer,RTC_START)==1)
    {
      sendEthercatDriverCommand(commands_to_string(RTC_START));
      isRtcRunning=1;
      n=write(newsockfd, ok_responses_to_string(RTC_START), ok_response_length(RTC_START));
    }
    else if (isServerCommand(buffer, START_TRANSFER)==1)
    { // START_TRANSFER
      if (currentServerState==0)
      {
        pthread_mutex_lock(&mutexServerState);
        serverState=1;
        pthread_mutex_unlock(&mutexServerState);

        pthread_t tid;
        int err=pthread_create(&tid, NULL, &runDataServer, NULL);
        if (err!=0)
        {
          printf("ETHCAT_SERVER: Thread runDataServer error.\n");
        }

        n=write(newsockfd, ok_responses_to_string(START_TRANSFER), ok_response_length(START_TRANSFER));
      }
      else
      {
        n=write(newsockfd, err_responses_to_string(START_TRANSFER), err_response_length(START_TRANSFER));
      }
    }
    else if (isServerCommand(buffer, RTC_STOP)==1)
    { // STC_STOP
      sendEthercatDriverCommand(commands_to_string(RTC_STOP));
      isRtcRunning=0;

      n=write(newsockfd, ok_responses_to_string(RTC_STOP), ok_response_length(RTC_START));
    }
    else if (isServerCommand(buffer, STOP_TRANSFER)==1)
    { // STOP_TRANSFER
      if (currentServerState==1)
      {
        pthread_mutex_lock(&mutexServerState);
        serverState=0;
        pthread_mutex_unlock(&mutexServerState);

        n=write(newsockfd, ok_responses_to_string(STOP_TRANSFER), ok_response_length(STOP_TRANSFER));
      }
      else
      {
        n=write(newsockfd, err_responses_to_string(STOP_TRANSFER), err_response_length(STOP_TRANSFER));
      }
    }
    else if (isServerCommand(buffer, RTC_IS_RUNNING)==1)
    { // RTC_IS_RUNNING
      if (isRtcRunning==1)
      {
        n=write(newsockfd, ok_responses_to_string(RTC_IS_RUNNING), ok_response_length(RTC_IS_RUNNING));
      }
      else
      {
        n=write(newsockfd, err_responses_to_string(RTC_IS_RUNNING), err_response_length(RTC_IS_RUNNING));
      }
    }
    else if (isServerCommand(buffer, IS_TRANSFER_RUNNING)==1)
    { // IS_TRANSFER_RUNNING
      if (currentServerState==1)
      {
        n=write(newsockfd, ok_responses_to_string(IS_TRANSFER_RUNNING), ok_response_length(IS_TRANSFER_RUNNING));
      }
      else
      {
        n=write(newsockfd, err_responses_to_string(IS_TRANSFER_RUNNING), err_response_length(IS_TRANSFER_RUNNING));
      }
    }
    else if (isServerCommand(buffer, RTC_GET_VERSION)==1)
    { // RTC_GET_VERSION
      n=write(newsockfd, ok_responses_to_string(RTC_GET_VERSION), ok_response_length(RTC_GET_VERSION));
    }
    else if (isServerCommand(buffer, GET_VERSION)==1)
    { // GET_VERSION
      n=write(newsockfd, ok_responses_to_string(GET_VERSION), ok_response_length(GET_VERSION));
    }
//    else if (isServerCommand(buffer, RTC_PAUSE)==1)
//    { // PAUSE
//      n=write(newsockfd, "+ERR Server paused... se pride\r\n", 32);
//    }
    else if (isServerCommand(buffer, PING)==1)
    { // PING
      n=write(newsockfd, ok_responses_to_string(PING), ok_response_length(PING));
    }
//    else if (strncmp(buffer, "STATUS_TEMPLATE", strlen("STATUS_TEMPLATE")) == 0)
//    { // STATUS
//      n=write(newsockfd, "+ERR Status... se pride\r\n", 25);
//    }
    else if (isServerCommand(buffer, RTC_SET_MEM)==1)
    { // PING

int offset=2;
int length=5;
char memData[4000];
sscanf(buffer+11, "%d %d %s", &offset, &length, memData);
char newCommand[50];
sprintf(newCommand, "RTC_MEM_OFFSET %d", offset);
sendEthercatDriverCommand(newCommand);
sprintf(newCommand, "RTC_MEM_LENGTH %d", length);
sendEthercatDriverCommand(newCommand);

setMemoryData(memData);


      n=write(newsockfd, ok_responses_to_string(IS_TRANSFER_RUNNING), ok_response_length(IS_TRANSFER_RUNNING));
    }
    else if (isServerCommand(buffer, RTC_GET_MEM)==1)
    { // PING

//printf("Command: %s\n", buffer);
int offset=2;
int length=5;
char memData[4000];
sscanf(buffer+11, "%d %d", &offset, &length);
char newCommand[50];
sprintf(newCommand, "RTC_MEM_OFFSET %d", offset);
sendEthercatDriverCommand(newCommand);
sprintf(newCommand, "RTC_MEM_LENGTH %d", length);
sendEthercatDriverCommand(newCommand);

int length1=getMemoryData(memData);
//setMemoryData();

      n=write(newsockfd, memData, length1);

//      n=write(newsockfd, err_responses_to_string(RTC_GET_MEM), err_response_length(RTC_GET_MEM));



    }
    else if (isServerCommand(buffer, RTC_COMMAND)==1)
    { // PING
/*
char memData[4000];
sscanf(buffer+13, "%s", memData);
char newCommand[50];
sprintf(newCommand, "RTC_COMMAND %s", memData);
sendEthercatDriverCommand(newCommand);
*/
sendEthercatDriverCommand(buffer);

      n=write(newsockfd, ok_responses_to_string(IS_TRANSFER_RUNNING), ok_response_length(IS_TRANSFER_RUNNING));
    }
    else if (isServerCommand(buffer, TO_FILE)==1)
    { // WRITE TO FILE
      pthread_t tid;
      int err=pthread_create(&tid, NULL, &writeMeasureDataToFile, NULL);
      if (err!=0)
      {
        printf("ETHCAT_SERVER: Thread writeMeasureDataToFile error.\n");
      }

      n=write(newsockfd, "+OK\r\n", 5);
    }
    else if (isServerCommand(buffer, STOP_SERVER)==1)
    { // STOP SERVER
        pthread_mutex_lock(&mutexServerState);
        serverState=-1;
        pthread_mutex_unlock(&mutexServerState);
        currentServerState=-1;
    }
    else
    {
      n=write(newsockfd, "+ERR unknown command\r\n", 23);
    }

    if (n<0)
    {
      printf("ETHCAT_SERVER: Error writing (response) to COMMAND socket.\n");
    }

    close(newsockfd);
  }

  close(commandSocket);

  close(dataSocket);

  printf("ETHCAT_SERVER: Closed command port.\n");

  return NULL;
}


void* runDataServer(void *args)
{
  int n;
  int currentDataSize=0;
  int currentServerState=0;

  struct sockaddr_in clientAddr;
  socklen_t clilen;
  clilen=sizeof(clientAddr);

  int newsockfd=accept(dataSocket, (struct sockaddr *) &clientAddr, &clilen);
  if (newsockfd<0)
  {
    printf("ETHCAT_SERVER: Error on DATA accept.\n");
  }

  int indexReader=0;

  pthread_mutex_lock(&mutexDataSize);
  indexReader=reading->size;
  pthread_mutex_unlock(&mutexDataSize);

  if (indexReader==0)
  {
    indexReader=-1;
  }
  else
  {
    if (indexReader>1)
    {
      indexReader--;
    }
    indexReader*=-1;
  }

  // set indexReader on the begining of message (search MESSAGE_ID)
  do
  {
    pthread_mutex_lock(&mutexDataSize);
    currentDataSize=reading->size;
    pthread_mutex_unlock(&mutexDataSize);

    if ((currentDataSize+indexReader)>0)
    {  // there are at least 2 bytes to search for MESSAGE_ID
      int messageId=MESSAGE_ID;
      int messageIdCh1=(char)(messageId);
      messageId=messageId>>8;
      int messageIdCh2=(char)(messageId);
      int dataCh1=(char)*(reading->data+(indexReader*-1)-1);
      int dataCh2=(char)*(reading->data+(indexReader*-1));

      if ((messageIdCh1==dataCh1) && (messageIdCh2==dataCh2))
      {
        indexReader++;
        indexReader*=-1;
      }
      else
      {
        indexReader--;
      }
    }
    if (currentDataSize==DATA_BUFFER_SIZE)
    {
      if (reading->next!=NULL)
      {
        reading=reading->next;
        indexReader=-1;
      }
    }

    usleep(100);

    pthread_mutex_lock(&mutexServerState);
    currentServerState=serverState;
    pthread_mutex_unlock(&mutexServerState);
  }
  while ((indexReader<0) && (currentServerState==1));

  while (currentServerState==1)
  {
    pthread_mutex_lock(&mutexDataSize);
    currentDataSize=reading->size;
    pthread_mutex_unlock(&mutexDataSize);

    if (indexReader<currentDataSize)
    {
      int sizeToWrite=currentDataSize-indexReader;

      n=write(newsockfd, reading->data+indexReader, sizeToWrite);
      if (n<0)
      {
printf("ERROR ON WRITE\n");
fflush(stdout);
        break;
      }

      if (sizeToWrite!=n)
      {
        printf("WRONG SIZE %d (%d, %d)\n", n, indexReader, sizeToWrite);
        fflush(stdout);

        pthread_mutex_lock(&mutexServerState);
        serverState=0;
        pthread_mutex_unlock(&mutexServerState);
        currentServerState=0;
      }

/*
int packetChecking=0;
while(packetChecking<indexReader)
{
  if (reading->data+packetChecking!=55)
  {
    printf("Wrong start 1 %d %c", packetChecking, reading->data+packetChecking);
  }
//  if (reading->data+packetChecking+1!=55)
//  {
//    printf("Wrong start 2 %d %c", packetChecking+1, reading->data+packetChecking+1);
//  }


  packetChecking+=20;
}
*/

      indexReader=indexReader+n;
    }
    else if (indexReader==DATA_BUFFER_SIZE)
    {
      if (reading->next!=NULL)
      {
        reading=reading->next;
        indexReader=0;
      }
    }
    usleep(100);

    pthread_mutex_lock(&mutexServerState);
    currentServerState=serverState;
    pthread_mutex_unlock(&mutexServerState);
  }

  close(newsockfd);

  return NULL;
}

// reads data from driver and saves it into "last" buffer
void readDataFromDriver(void)
{
  FILE *ifStream;
  int currentDataSize=0;
  int currentServerState=0;

  ifStream=fopen("/dev/ethcat", "r");
  if (ifStream==NULL)
  {
    printf("ETHCAT_SERVER: Error opening driver data.\n");
  }

  while (currentServerState!=-1)
  {
    //char ch;
    int ch;
    while ((ch=fgetc(ifStream))!=EOF)
    {
      //printf("%d ", (int)ch);

      pthread_mutex_lock(&mutexDataSize);
      currentDataSize=last->size;
      last->data[currentDataSize]=(char)ch;
      last->size++;
      pthread_mutex_unlock(&mutexDataSize);

      currentDataSize++;

/*
if (currentDataSize%10000==0)
{
  printf("Novih 10k iz driverja %d.\n", currentDataSize);
}
*/

      if (currentDataSize>=DATA_BUFFER_SIZE)
      {
        getNewMeasureDataSpace();
      }
    } // while there are data available

    pthread_mutex_lock(&mutexServerState);
    currentServerState=serverState;
    pthread_mutex_unlock(&mutexServerState);

    usleep(5000);
  }

  fclose(ifStream);

  printf("ETHCAT_SERVER: Closed driver data read.\n");
  fflush(stdout);
}

void sendEthercatDriverCommand(char *command)
{
//  FILE *ofStream=fopen("/dev/ethcat", "w");
  FILE *ofStream=fopen("/sys/bus/ethcat/commandData", "w");
  fprintf(ofStream, "%s", command);
  fclose(ofStream);
}

void getNewMeasureDataSpace(void)
{
  struct MeasureData *newData;
  newData=malloc(sizeof(struct MeasureData));
  newData->size=0;
  newData->next=NULL;
  if (last!=NULL)
  {
    newData->id=last->id+1;
    last->next=newData;
  }
  else
  {
    newData->id=1;
  }
  last=newData;
}

void* writeMeasureDataToFile(void *args)
{
  //  struct MeasureData *measureData=(struct MeasureData *)args;
  struct MeasureData *data=first;

  while (data!=NULL)
  {
    int currentDataSize=0;
    char fileName[15]="data0000.ec";
    int fileIndex=((float) data->id/(float)NUM_BUFFERS_TO_FILE)+1;
    fileName[7]=(char)fileIndex+'0';

    FILE *fp;
    if ((data->id==1) || ((data->id%NUM_BUFFERS_TO_FILE)==0))
    {
      fp=fopen(fileName, "w");
    }
    else
    {
      fp=fopen(fileName, "a+");
    }
    if (fp!=NULL)
    {
      pthread_mutex_lock(&mutexDataSize);
      currentDataSize=data->size;
      pthread_mutex_unlock(&mutexDataSize);

      fwrite(data->data, 1, currentDataSize, fp);
    }
    fclose(fp);

    data=data->next;
    //    struct MeasureData *deleteData=first;
    //    first=first->next;
    //    free (deleteData);
  }

  //  if (first==NULL)
  //  {
  //    last=NULL;
  //  }

  return NULL;
}

int main(void)
{
  first=NULL;
  last=NULL;
  reading=NULL;

  serverState=0;
  isRtcRunning=0;


  if (pthread_mutex_init(&mutexDataSize, NULL)!=0)
  {
    return -1;
  }
  if (pthread_mutex_init(&mutexServerState, NULL)!=0)
  {
    return -1;
  }


  resetEthercatDriver();


  getNewMeasureDataSpace();
  first=last;
  reading=last;

  pid_t childPID;
  childPID=fork();
  if (childPID>=0) // fork was successful
  {
    if (childPID==0) // child process
    {
      if (initCommandServer()!=0)
      {
        printf("ETHCAT_SERVER: Server is not running (initCommandServer).\n");
        return -1;
      }
      if (initDataServer()!=0)
      {
        printf("ETHCAT_SERVER: Server is not running (initDataServer).\n");
        return -2;
      }

      printf("ETHCAT_SERVER: Server is running.\n");

      readDataFromDriver();

      pthread_mutex_destroy(&mutexDataSize);
      pthread_mutex_destroy(&mutexServerState);

      usleep(500000);    // give time to othe threads to stop
      printf("ETHCAT_SERVER: Server is down.\n");
    }
  }
  else // fork failed
  {
    printf("ETHCAT_SERVER: Server is not running (fork).\n");
    return -3;
  }

  return 0;
}

