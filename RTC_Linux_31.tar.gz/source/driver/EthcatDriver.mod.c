#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x390bbe87, "module_layout" },
	{ 0x6e41482c, "ecrt_master_receive" },
	{ 0xcb2304ce, "cdev_del" },
	{ 0xd2b09ce5, "__kmalloc" },
	{ 0xd1ffb4c5, "cdev_init" },
	{ 0x6c6ce6fb, "ecrt_master_create_domain" },
	{ 0xf9a482f9, "msleep" },
	{ 0xf9fcb3b3, "ecrt_version_magic" },
	{ 0xe15d7fe8, "ecrt_master_send" },
	{ 0x1b17e06c, "kstrtoll" },
	{ 0xe4f8dcff, "__mutex_do_init" },
	{ 0xfab24c5e, "hrtimer_forward" },
	{ 0xe529836c, "ecrt_domain_queue" },
	{ 0x6982e1a7, "hrtimer_cancel" },
	{ 0x120015cf, "__rt_mutex_init" },
	{ 0xa850db90, "ecrt_master_sync_slave_clocks" },
	{ 0x53ac4454, "device_destroy" },
	{ 0xb9115970, "ecrt_master_send_ext" },
	{ 0xdb4cef73, "_mutex_unlock" },
	{ 0x7485e15e, "unregister_chrdev_region" },
	{ 0xa66b0858, "ecrt_domain_reg_pdo_entry_list" },
	{ 0x4286308f, "ecrt_master_application_time" },
	{ 0x142892b6, "kthread_create_on_node" },
	{ 0x71de9b3f, "_copy_to_user" },
	{ 0x67c122ca, "ecrt_domain_process" },
	{ 0x15e99814, "ecrt_domain_state" },
	{ 0xf27a75a5, "ecrt_master_callbacks" },
	{ 0x6d5af58b, "ecrt_master_state" },
	{ 0x65c250b9, "ecrt_slave_config_state" },
	{ 0x27e1a049, "printk" },
	{ 0x6480b4e4, "ecrt_master_slave_config" },
	{ 0x2a9e1707, "set_cpus_allowed_ptr" },
	{ 0xdd1a2871, "down" },
	{ 0xbf399363, "device_create" },
	{ 0xa567e8b6, "ecrt_slave_config_dc" },
	{ 0xb77309ba, "ecrt_master_sync_reference_clock" },
	{ 0xefe0653a, "cdev_add" },
	{ 0xe14193ef, "ecrt_domain_external_memory" },
	{ 0xed1ae700, "ecrt_domain_size" },
	{ 0xcf4b17e7, "hrtimer_start" },
	{ 0x2452fe04, "wake_up_process" },
	{ 0x37a0cba, "kfree" },
	{ 0xc08ace3a, "ecrt_master_activate" },
	{ 0xf7ebdfbd, "hrtimer_init" },
	{ 0xe2f0ef5c, "ecrt_release_master" },
	{ 0xc4554217, "up" },
	{ 0xf53cfe23, "ecrt_request_master" },
	{ 0xe6254dab, "class_destroy" },
	{ 0x6f572505, "_mutex_lock" },
	{ 0x77e2f33, "_copy_from_user" },
	{ 0x3f492a75, "__class_create" },
	{ 0x29537c9e, "alloc_chrdev_region" },
	{ 0xe914e41e, "strcpy" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=ec_master";


MODULE_INFO(srcversion, "F136586F9047E0ED4A04B52");
