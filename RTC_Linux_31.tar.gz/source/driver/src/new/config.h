//#ifndef __CONFIG_H__
//#define __CONFIG_H__

#ifdef __KERNEL__
#include <asm/byteorder.h>
#include <linux/types.h>
#include <linux/time.h>
#else
#include <stdlib.h> // for size_t
#include <stdint.h>
#include <sys/time.h> // for struct timeval
#endif

#define DEWESOFT_MODULE 1

static unsigned int output1_pos; // offsets for PDO entries
static unsigned int output2_pos;
static unsigned int input1_pos;
static unsigned int input2_pos;
static unsigned int input3_pos;

static unsigned int input2_align;
static unsigned int output1_align;

#define EK1101Pos 0, 0
#define KryptonTH 0, 0
#define EL4132Pos 0, 1
#define EL3312Pos 0, 1


#define EL3124Pos 0, 2
#define EL3702Pos 0, 3
#define EL1808Pos 0, 4


#define Beckhoff_EK1101 0x00000002, 0x044d2c52
#define Beckhoff_EL3312 0x00000002, 0x0cf03052
#define Beckhoff_EL4132 0x00000002, 0x10243052
#define Beckhoff_EL3124 0x00000002, 0x0c343052
#define Beckhoff_EL3702 0x00000002, 0x0e763052 
#define Beckhoff_EL1808 0x00000002, 0x07103052

#define Dewesoft_KryptonTH 0xdebe50f7, 0x00000064

#if DEWESOFT_MODULE

static unsigned int input3_pos;
static unsigned int input3_pos2;

const static ec_pdo_entry_reg_t domain1_regs[] = {
    {KryptonTH, Dewesoft_KryptonTH, 0x7010, 0x01, &output1_pos, &output1_align},
    {KryptonTH, Dewesoft_KryptonTH, 0x6040, 0x01, &input1_pos},
    {KryptonTH, Dewesoft_KryptonTH, 0x6040, 0x02, &input2_pos},
// 	{KryptonTH, Dewesoft_KryptonTH, 0x6041, 0x01, &input3_pos}, /* T TC 2 */
// 	{KryptonTH, Dewesoft_KryptonTH, 0x6041, 0x02, &input3_pos2}, /* T TC 2 */
    {}
};
#else
const static ec_pdo_entry_reg_t domain1_regs[] = {
    {EL3312Pos,  Beckhoff_EL3312, 0x6000, 0x11, &input1_pos},
    {}
  };
#endif
  
  #ifdef CONFIGURE_PDOS
/* Master 0, Slave 0, "EK1101"
 * Vendor ID:       0x00000002
 * Product code:    0x044d2c52
 * Revision number: 0x00110000
 */

ec_pdo_entry_info_t slave_0_pdo_entries[] = {
    {0x6000, 0x01, 16}, /* ID */
};

ec_pdo_info_t slave_0_pdos[] = {
    {0x1a00, 1, slave_0_pdo_entries + 0}, /* ID */
};

ec_sync_info_t slave_0_syncs[] = {
    {0, EC_DIR_INPUT, 1, slave_0_pdos + 0, EC_WD_DISABLE},
    {0xff}
};

/* Master 0, Slave 1, "EL3312"
 * Vendor ID:       0x00000002
 * Product code:    0x0cf03052
 * Revision number: 0x00120000
 */

ec_pdo_entry_info_t slave_1_pdo_entries[] = {
    {0x6000, 0x01, 1}, /* Underrange */
    {0x6000, 0x02, 1}, /* Overrange */
    {0x6000, 0x03, 2}, /* Limit 1 */
    {0x6000, 0x05, 2}, /* Limit 2 */
    {0x6000, 0x07, 1}, /* Error */
    {0x0000, 0x00, 7}, /* Gap */
    {0x6000, 0x0f, 1}, /* TxPDO State */
    {0x1800, 0x09, 1},
    {0x6000, 0x11, 16}, /* Value */
    {0x6010, 0x01, 1}, /* Underrange */
    {0x6010, 0x02, 1}, /* Overrange */
    {0x6010, 0x03, 2}, /* Limit 1 */
    {0x6010, 0x05, 2}, /* Limit 2 */
    {0x6010, 0x07, 1}, /* Error */
    {0x0000, 0x00, 7}, /* Gap */
    {0x6010, 0x0f, 1}, /* TxPDO State */
    {0x1801, 0x09, 1},
    {0x6010, 0x11, 16}, /* Value */
};

ec_pdo_info_t slave_1_pdos[] = {
    {0x1a00, 9, slave_1_pdo_entries + 0}, /* TC TxPDO-MapCh.1 */
    {0x1a01, 9, slave_1_pdo_entries + 9}, /* TC TxPDO-MapCh.2 */
};

ec_sync_info_t slave_1_syncs[] = {
    {0, EC_DIR_OUTPUT, 0, NULL, EC_WD_DISABLE},
    {1, EC_DIR_INPUT, 0, NULL, EC_WD_DISABLE},
    {2, EC_DIR_OUTPUT, 0, NULL, EC_WD_DISABLE},
    {3, EC_DIR_INPUT, 2, slave_1_pdos + 0, EC_WD_DISABLE},
    {0xff}
};


/* Master 0, Slave 0, "Titan_V2.00"
 * Vendor ID:       0xdebe50f7
 * Product code:    0x00000064
 * Revision number: 0x00010111
 */

ec_pdo_entry_info_t slave_4_pdo_entries[] = {
    {0x7010, 0x01, 1}, /* LED1 */
    {0x7010, 0x02, 1}, /* LED2 */
    {0x7010, 0x03, 1}, /* LED3 */
    {0x7010, 0x04, 1}, /* LED4 */
    {0x0000, 0x00, 12}, /* Gap */
    {0x7010, 0x06, 32}, /* Reg0 */
    {0x7010, 0x07, 32}, /* Reg1 */
    {0x7010, 0x08, 32}, /* Reg2 */
    {0x6000, 0x01, 1}, /* FirstSample */
    {0x6000, 0x02, 1}, /* Switch 2 */
    {0x6000, 0x03, 1}, /* ReadToggle */
    {0x6000, 0x04, 1}, /* Switch 4 */
    {0x0000, 0x00, 4}, /* Gap */
    {0x6000, 0x06, 8}, /* Counter */
    {0x6000, 0x07, 32}, /* BufCounter */
    {0x6000, 0x08, 32}, /* Reg1 */
    {0x6000, 0x09, 32}, /* Reg2 */
    {0x6000, 0x0a, 64}, /* Timestamp */
    {0x6040, 0x01, 32}, /* T TC 1 */
    {0x6040, 0x02, 32}, /* T PT1000 1 */
    {0x6041, 0x01, 32}, /* T TC 2 */
    {0x6041, 0x02, 32}, /* T PT1000 2 */
    {0x6042, 0x01, 32}, /* T TC 3 */
    {0x6042, 0x02, 32}, /* T PT1000 3 */
    {0x6043, 0x01, 32}, /* T TC 4 */
    {0x6043, 0x02, 32}, /* T PT1000 4 */
    {0x6044, 0x01, 32}, /* T TC 5 */
    {0x6044, 0x02, 32}, /* T PT1000 5 */
    {0x6045, 0x01, 32}, /* T TC 6 */
    {0x6045, 0x02, 32}, /* T PT1000 6 */
    {0x6046, 0x01, 32}, /* T TC 7 */
    {0x6046, 0x02, 32}, /* T PT1000 7 */
    {0x6047, 0x01, 32}, /* T TC 8 */
    {0x6047, 0x02, 32}, /* T PT1000 8 */
    {0x6048, 0x01, 32}, /* T TC 9 */
    {0x6048, 0x02, 32}, /* T PT1000 9 */
    {0x6049, 0x01, 32}, /* T TC 10 */
    {0x6049, 0x02, 32}, /* T PT1000 10 */
    {0x604a, 0x01, 32}, /* T TC 11 */
    {0x604a, 0x02, 32}, /* T PT1000 11 */
    {0x604b, 0x01, 32}, /* T TC 12 */
    {0x604b, 0x02, 32}, /* T PT1000 12 */
    {0x604c, 0x01, 32}, /* T TC 13 */
    {0x604c, 0x02, 32}, /* T PT1000 13 */
    {0x604d, 0x01, 32}, /* T TC 14 */
    {0x604d, 0x02, 32}, /* T PT1000 14 */
    {0x604e, 0x01, 32}, /* T TC 15 */
    {0x604e, 0x02, 32}, /* T PT1000 15 */
    {0x604f, 0x01, 32}, /* T TC 16 */
    {0x604f, 0x02, 32}, /* T PT1000 16 */
};

ec_pdo_info_t slave_4_pdos[] = {
    {0x1601, 8, slave_4_pdo_entries + 0}, /* DO RxPDO-Map */
    {0x1a00, 10, slave_4_pdo_entries + 8}, /* DI TxPDO-Map */
    {0x1a40, 2, slave_4_pdo_entries + 18}, /* T1 TxPDO-Map */
    {0x1a41, 2, slave_4_pdo_entries + 20}, /* T2 TxPDO-Map */
    {0x1a42, 2, slave_4_pdo_entries + 22}, /* T3 TxPDO-Map */
    {0x1a43, 2, slave_4_pdo_entries + 24}, /* T4 TxPDO-Map */
    {0x1a44, 2, slave_4_pdo_entries + 26}, /* T5 TxPDO-Map */
    {0x1a45, 2, slave_4_pdo_entries + 28}, /* T6 TxPDO-Map */
    {0x1a46, 2, slave_4_pdo_entries + 30}, /* T7 TxPDO-Map */
    {0x1a47, 2, slave_4_pdo_entries + 32}, /* T8 TxPDO-Map */
    {0x1a48, 2, slave_4_pdo_entries + 34}, /* T9 TxPDO-Map */
    {0x1a49, 2, slave_4_pdo_entries + 36}, /* T10 TxPDO-Map */
    {0x1a4a, 2, slave_4_pdo_entries + 38}, /* T11 TxPDO-Map */
    {0x1a4b, 2, slave_4_pdo_entries + 40}, /* T12 TxPDO-Map */
    {0x1a4c, 2, slave_4_pdo_entries + 42}, /* T13 TxPDO-Map */
    {0x1a4d, 2, slave_4_pdo_entries + 44}, /* T14 TxPDO-Map */
    {0x1a4e, 2, slave_4_pdo_entries + 46}, /* T15 TxPDO-Map */
    {0x1a4f, 2, slave_4_pdo_entries + 48}, /* T16 TxPDO-Map */
};

ec_sync_info_t slave_4_syncs[] = {
    {0, EC_DIR_OUTPUT, 0, NULL, EC_WD_DISABLE},
    {1, EC_DIR_INPUT, 0, NULL, EC_WD_DISABLE},
    {2, EC_DIR_OUTPUT, 1, slave_4_pdos + 0, EC_WD_ENABLE},
    {3, EC_DIR_INPUT, 17, slave_4_pdos + 1, EC_WD_DISABLE},
    {0xff}
};


#endif
