typedef unsigned int uint;

#define RTC_INFO(s, ...) printk(KERN_INFO "INFO " PFX s, ##__VA_ARGS__);
#define RTC_ERR(s, ...) printk(KERN_ERR "ERR " PFX s, ##__VA_ARGS__);

static char* state_to_string[] = {"INIT", "PREOP", "SAFEOP", "OP"};

#define AL_STATE(s) state_to_string[s - 1]
#define UINT_TF(int) int ? "true" : "false"

// int snprintf(char *buf, size_t size, const char *fmt, ...)
// {
//     va_list args;
//     int i;
// 
//     va_start(args, fmt);
//     i = vsnprintf(buf, size, fmt, args);
//     va_end(args);
// 
//     return i;
// }
// EXPORT_SYMBOL(snprintf);