/******************************************************************************
 *
 *  $Id$
 *
 *  Copyright (C) 2006-2008  Florian Pose, Ingenieurgemeinschaft IgH
 *
 *  This file is part of the IgH EtherCAT Master.
 *
 *  The IgH EtherCAT Master is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License version 2, as
 *  published by the Free Software Foundation.
 *
 *  The IgH EtherCAT Master is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 *  Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with the IgH EtherCAT Master; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 *  ---
 *
 *  The license mentioned above concerns the source code only. Using the
 *  EtherCAT technology and brand is only permitted in compliance with the
 *  industrial property and similar rights of Beckhoff Automation GmbH.
 *
 *****************************************************************************/

#include <linux/hrtimer.h>
#include <linux/ktime.h>
#include <linux/version.h>
#include <linux/module.h>
#include <linux/timer.h>
#include <linux/interrupt.h>
#include <linux/err.h>
#include <linux/slab.h>
#include <linux/semaphore.h>
#include "ecrt.h" // EtherCAT realtime interface
#include "config.h"
#include "defs.h"

#include <asm/i387.h>

/*****************************************************************************/
#include <linux/fs.h>                 // za nastavitev toka
#include <linux/device.h>             // za prijavo gonilnika
#include <linux/cdev.h>
#include <linux/uaccess.h>            // branje in pisanje podatkov uporabnika
#include <linux/kthread.h>
#include <linux/delay.h>
#include <linux/string.h>
#include <linux/stddef.h>

/*****************************************************************************/
static dev_t first;       // Global variable for the first device number
static struct cdev c_dev; // Global variable for the character device structure
static struct class* cl;  // Global variable for the device class

//#define  DATA_BUFFER_SIZE 1048576
#define DATA_BUFFER_SIZE 32000
#define PACKET_ID 21845

char ethcatData[DATA_BUFFER_SIZE];
int  indexWriter = 0;
int  indexReader = 0;
unsigned int measureNumber = 0;
struct mutex mutexIndexWriter;
struct mutex mutexIsGeneratorRunning;
int isGeneratorRunning = 0;
//struct task_struct *task;

/////////////////////
// COMMANDS
/////////////////////
typedef enum
{
    RTC_RUN,
    RTC_STOP,
    IS_RTC_RUNNING
} driver_deamon_commands_t;

static inline char* commands_to_string(driver_deamon_commands_t s)
{
    static char* strings[] =
    {"RTC_RUN", "RTC_STOP", "IS_RTC_RUNNING"};
    return strings[s];
}

/*****************************************************************************/
// Module parameters
int FREQUENCY = 3000;
int NSEC_SEC = 1000000000;
#define FREQ_NSEC (NSEC_SEC / FREQUENCY)
// Optional features
#define EXTERNAL_MEMORY 1
#define PFX "RTC DRIVER: "
/*****************************************************************************/

// EtherCAT
static ec_master_t* master = NULL;
static ec_master_state_t master_state = {};
struct semaphore master_sem;

static ec_domain_t* domain1 = NULL;
static ec_domain_state_t domain1_state = {};

//static ec_slave_config_t *sc_ana_in = NULL;
//static ec_slave_config_state_t sc_ana_in_state = {};

static struct hrtimer hr_timer;
static ktime_t ktime;

struct timeval tv;

/*****************************************************************************/

// process data
static uint8_t* domain1_pd; // process data memory

unsigned int size;

/*****************************************************************************/

bool led1On;
bool led2On;
bool led3On;
bool led4On;

int do_calc(int input)
{
    double y;
    double x;
    kernel_fpu_begin();

    y = 2.23;
    x = 3.14;
    x += y;
    x = x * 100;

//    printk(KERN_INFO PFX "X= %u",(int)x);

    kernel_fpu_end();
    input += (int)x;
    return input;
}



/*****************************************************************************/
void trafficGenerator(void)
{
    /*************************/
    int currentIsGeneratorRunning = 0;
    uint input1;
    uint input2TC;
    /*************************/

    mutex_lock(&mutexIsGeneratorRunning);
    currentIsGeneratorRunning = isGeneratorRunning;
    mutex_unlock(&mutexIsGeneratorRunning);

    input1 = EC_READ_U32(domain1_pd + input1_pos);

    //Pt1000 temp
    RTC_INFO("Temp: %u\n", input1);

    mutex_lock(&mutexIsGeneratorRunning);
    currentIsGeneratorRunning = isGeneratorRunning;
    mutex_unlock(&mutexIsGeneratorRunning);
}


/*****************************************************************************/

void check_domain1_state(void)
{
    ec_domain_state_t ds;

    down(&master_sem);
    ecrt_domain_state(domain1, &ds);
    up(&master_sem);

    if (ds.working_counter != domain1_state.working_counter)
        printk(KERN_INFO PFX "Domain1: WC %u.\n", ds.working_counter);

    if (ds.wc_state != domain1_state.wc_state)
        printk(KERN_INFO PFX "Domain1: State %u.\n", ds.wc_state);

    domain1_state = ds;
}

/*****************************************************************************/

void check_master_state(void)
{
    ec_master_state_t ms;

    down(&master_sem);
    ecrt_master_state(master, &ms);
    up(&master_sem);

    if (ms.slaves_responding != master_state.slaves_responding) {
        printk(KERN_INFO PFX "%u slave(s).\n", ms.slaves_responding);
    }

    if (ms.al_states != master_state.al_states) {
        printk(KERN_INFO PFX "AL states: 0x%02X.\n", ms.al_states);
    }

    if (ms.link_up != master_state.link_up) {
        printk(KERN_INFO PFX "Link is %s.\n", ms.link_up ? "up" : "down");
    }

    master_state = ms;
}

/*****************************************************************************/
void cancel_hrtimer(void)
{
    hrtimer_cancel(&hr_timer);
}

/*****************************************************************************/
static enum hrtimer_restart cyclic_task(struct hrtimer* timer)
{
    unsigned int sync_ref_counter = 0;

    if (isGeneratorRunning == 1)
    {
        // receive process data
        down(&master_sem);
        ecrt_master_receive(master);
        ecrt_domain_process(domain1);
        up(&master_sem);

        check_domain1_state();

        check_master_state();

        trafficGenerator();

        // send process data
        down(&master_sem);

        //END START Dewesoft Module
        tv.tv_usec += FREQ_NSEC / 1000; //freq time

        if (tv.tv_usec > 1000000)
        {
            tv.tv_usec -= 1000000;
            tv.tv_sec++;
        }

        ecrt_master_application_time(master, EC_TIMEVAL2NANO(tv));

        if (sync_ref_counter)
        {
            sync_ref_counter--;
        }
        else
        {
            sync_ref_counter = 9;
            ecrt_master_sync_reference_clock(master);
        }

        ecrt_master_sync_slave_clocks(master);
        //END Dewesoft Module


        ecrt_domain_queue(domain1);
        ecrt_master_send(master);
        up(&master_sem);
        hrtimer_forward_now(&hr_timer, ktime);
        return HRTIMER_RESTART;
    }
    else
    {
        printk("cyclic_task loop end \n");
        return HRTIMER_NORESTART;
    }

}

static int kthread_hrtimer(void* arg)
{
    printk(KERN_INFO PFX "Starting cyclic sample thread.\n");
    hrtimer_init(&hr_timer, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
    hr_timer.function = &cyclic_task;
    ktime = ktime_set( 0, FREQ_NSEC );

    // gettimeofday(&tv, NULL);
    tv.tv_sec = 0;
    tv.tv_usec = 0;

    hrtimer_start(&hr_timer, ktime, HRTIMER_MODE_REL);
    return 0;
}

int init_hrtimer(void)
{
    struct task_struct* thread;

    cpumask_t mask;
    cpus_clear(mask);
    cpu_set(0, mask);

    thread = kthread_create(&kthread_hrtimer, NULL, "kthread_hrtimer");

    if(IS_ERR(thread))
    {
        printk("create failure\n");
        return 1;
    }

    set_cpus_allowed_ptr(thread, &mask);
    wake_up_process(thread);

    return 0;
}

void startMeasuring(void)
{
    int currentIsGeneratorRunning = 0;
    mutex_lock(&mutexIsGeneratorRunning);

    currentIsGeneratorRunning = isGeneratorRunning;

    mutex_unlock(&mutexIsGeneratorRunning);

    if (currentIsGeneratorRunning == 0)
    {
        mutex_lock(&mutexIsGeneratorRunning);
        isGeneratorRunning = 1;
        mutex_unlock(&mutexIsGeneratorRunning);

        init_hrtimer();
    }
}

void stopMeasuring(void)
{
//  printk(KERN_INFO "ETHERCAT_DRIVER: Stop measuring\n");
    mutex_lock(&mutexIsGeneratorRunning);

    if (isGeneratorRunning == 1)
    {
        isGeneratorRunning = 0;
        cancel_hrtimer();
        //kthread_stop(task);
    }

    mutex_unlock(&mutexIsGeneratorRunning);
}

void resetDriver(void)
{
    mutex_lock(&mutexIsGeneratorRunning);
    isGeneratorRunning = 0;
    mutex_unlock(&mutexIsGeneratorRunning);

    msleep(10);

    mutex_lock(&mutexIndexWriter);
    indexWriter = 0;
    indexReader = 0;
    measureNumber = 0;
    mutex_unlock(&mutexIndexWriter);
}

static int ethcat_open(struct inode* i, struct file* f)
{
    printk(KERN_INFO "RTC ETHERCAT_DRIVER: open()\n");
    return 0;
}

static int ethcat_close(struct inode* i, struct file* f)
{
    printk(KERN_INFO "RTC ETHRECAT_DRIVER: close()\n");
    return 0;
}

static ssize_t ethcat_read(struct file* f, char __user* buf, size_t len, loff_t* off)
{
    int sizeToRead = 0;
    int currentIndexWriter = 0;

    printk(KERN_INFO "RTC ETHERCAT_DRIVER: read()\n");

    mutex_lock(&mutexIndexWriter);
    currentIndexWriter = indexWriter;
    mutex_unlock(&mutexIndexWriter);

    if (currentIndexWriter > indexReader)
    {
        sizeToRead = currentIndexWriter - indexReader;

        if (copy_to_user(buf, ethcatData + indexReader, sizeToRead) != 0) {
            return -EFAULT;
        }
    }

    else if (currentIndexWriter != indexReader)
    {   // start reading from the beginig of the table
        sizeToRead = DATA_BUFFER_SIZE - indexReader;

        if (copy_to_user(buf, ethcatData + indexReader, sizeToRead) != 0) {
            return -EFAULT;
        }

        if (copy_to_user(buf + sizeToRead, ethcatData, currentIndexWriter) != 0)
            return -EFAULT;

        sizeToRead += currentIndexWriter;
    }

    indexReader = currentIndexWriter;

//  printk(KERN_INFO "ETHERCAT_DRIVER: reading()%d\n", sizeToRead);

    return sizeToRead;
}

static ssize_t ethcat_write(struct file* f, const char __user* buf, size_t len, loff_t* off)
{
    char commandStr[50];
    char tmpStr[50];
    long freq;


    //  printk(KERN_INFO "ETHERCAT_DRIVER: write()\n");

    if (copy_from_user(&commandStr, buf, len) != 0) {
        return -EFAULT;
    }

    commandStr[len] = '\0';

    if (strncmp(commandStr, "RTC_START", strlen("RTC_START")) == 0)
    {
        startMeasuring();
    }
    else if (strncmp(commandStr, "RTC_STOP", strlen("RTC_STOP")) == 0)
    {
        stopMeasuring();
    }
    else if (strncmp(commandStr, "RTC_RESET", strlen("RTC_RESET")) == 0)
    {
        resetDriver();
    }
    else if (strncmp(commandStr, "RTC_FREQ", strlen("RTC_FREQ")) == 0)
    {
        strcpy(tmpStr, commandStr + 9);

        if (kstrtol(tmpStr, 10, &freq) == 0)
        {
            if (freq > 100000)
            {
                freq = 100000;
            }

            printk("Frequency set to:%ld\n", freq);
            FREQUENCY = freq;
            stopMeasuring();
            startMeasuring();
        }
    }

    return len;
}

static struct file_operations pugs_fops =
{
    .owner = THIS_MODULE,
    .open = ethcat_open,
    .release = ethcat_close,
    .read = ethcat_read,
    .write = ethcat_write
};

/*****************************************************************************/

void send_callback(void* cb_data)
{
    ec_master_t* m = (ec_master_t*) cb_data;
    down(&master_sem);
    ecrt_master_send_ext(m);
    up(&master_sem);
}

/*****************************************************************************/

void receive_callback(void* cb_data)
{
    ec_master_t* m = (ec_master_t*) cb_data;
    down(&master_sem);
    ecrt_master_receive(m);
    up(&master_sem);
}

void printDebugInfo(void){
    uint vermagic = ecrt_version_magic();

    RTC_INFO("Version magic: %d.", vermagic);

    ec_master_state_t state;
    ecrt_master_state(master, &state);

    RTC_INFO("Num. slaves responding: %d", state.slaves_responding);
    RTC_INFO("Application layer states: %04x.", state.al_states);
    RTC_INFO("At least one ethernet link up: %s.", state.al_states ? "true" : "false");

    RTC_INFO("Checking configuraton for: %s", "KryptonTH");
    
    ec_slave_config_t* sc;
    if (!(sc = ecrt_master_slave_config(master, KryptonTH, Dewesoft_KryptonTH))) {
        RTC_ERR("Failed to get slave configuration for: %s", "KryptonTH");
    }

    ec_slave_config_state_t ss;
    ecrt_slave_config_state(sc, &ss);

    RTC_INFO("Slave is online: %d.", ss.online);
    RTC_INFO("Slave is operational: %s.", UINT_TF(ss.operational));
    RTC_INFO("Slave state: %s.", AL_STATE(ss.al_state));
}

/*****************************************************************************/

int __init init_mini_module(void)
{
    int ret = -1;

    unsigned int size;

    /*****************************************************************************/
    printk(KERN_INFO "RTC ETHCAT_DRIVER: Registered\n");

    isGeneratorRunning = 0;

    mutex_init(&mutexIndexWriter);
    mutex_init(&mutexIsGeneratorRunning);

    if (alloc_chrdev_region(&first, 0, 1, "ethcat") < 0)
    {
        printk(KERN_ALERT "RTC ETHERCAT_DRIVER: Device Registration failed\n");
        return -1;
    }

    if ((cl = class_create(THIS_MODULE, "ethcatdrv")) == NULL)
    {
        printk(KERN_ALERT "RTC ETHERCAT_DRIVER: Class creation failed\n");
        unregister_chrdev_region(first, 1);
        return -1;
    }

    if (device_create(cl, NULL, first, NULL, "ethcat") == NULL)
    {
        printk(KERN_ALERT "RTC ETHERCAT_DRIVER: Device creation failed\n");
        class_destroy(cl);
        unregister_chrdev_region(first, 1);
        return -1;
    }

    //init device operations to functions in pugs_fops
    cdev_init(&c_dev, &pugs_fops);

    if (cdev_add(&c_dev, first, 1) == -1)
    {
        printk(KERN_ALERT "RTC ETHERCAT_DRIVER: Device addition failed\n");
        device_destroy(cl, first);
        class_destroy(cl);
        unregister_chrdev_region(first, 1);
        return -1;
    }

    /*****************************************************************************/
    ec_slave_config_t* sc;

    printk(KERN_INFO PFX "Starting...\n");

    master = ecrt_request_master(0);

    if (!master) {
        ret = -EBUSY;
        printk(KERN_ERR PFX "Requesting master 0 failed.\n");
        goto out_return;
    }

    sema_init(&master_sem, 1);
    ecrt_master_callbacks(master, send_callback, receive_callback, master);

    printk(KERN_INFO PFX "Registering domain...\n");

    if (!(domain1 = ecrt_master_create_domain(master))) {
        printk(KERN_ERR PFX "Domain creation failed!\n");
        goto out_release_master;
    }

    printk(KERN_INFO PFX "Registering PDO entries...\n");

    if (ecrt_domain_reg_pdo_entry_list(domain1, domain1_regs)) {
        printk(KERN_ERR PFX "PDO entry registration failed!\n");
        goto out_release_master;
    }

    if (!(sc = ecrt_master_slave_config(master, KryptonTH, Dewesoft_KryptonTH))) {
        printk(KERN_ERR PFX "Failed to get slave configuration \n");
        goto out_release_master;
    }

    ecrt_slave_config_dc(sc, 0x0700, 500000, 0, 9500000, 0);

    if ((size = ecrt_domain_size(domain1))) {
        if (!(domain1_pd = (uint8_t*) kmalloc(size, GFP_KERNEL))) {
            printk(KERN_ERR PFX "Failed to allocate %u bytes of process data memory!\n", size);
            goto out_release_master;
        }

        ecrt_domain_external_memory(domain1, domain1_pd);
        printk(KERN_INFO PFX "External_MEMORY.\n");
        printk(KERN_INFO PFX "Domain_size: %d\n", size);
    }

    printk(KERN_INFO PFX "Activating master...\n");

    if (ecrt_master_activate(master)) {
        printk(KERN_ERR PFX "Failed to activate master!\n");
        goto out_free_process_data;
    }

    printk(KERN_INFO PFX "Started.\n");
    printDebugInfo();

    return 0;

out_free_process_data:
    kfree(domain1_pd);
out_release_master:
    printk(KERN_ERR PFX "Releasing master...\n");
    ecrt_release_master(master);
out_return:
    printk(KERN_ERR PFX "Failed to load. Aborting.\n");
    return ret;
}

/*****************************************************************************/

void __exit cleanup_mini_module(void)
{
    printk(KERN_INFO PFX "Stopping...\n");
    stopMeasuring();  
    kfree(domain1_pd);

    //RTC_INFO("Deactivating master");
    //ecrt_master_deactivate(master);

    printk(KERN_INFO PFX "Releasing master...\n");
    ecrt_release_master(master);

    printk(KERN_INFO PFX "Unloading.\n");
    /*****************************************************************************/
    cdev_del(&c_dev);
    device_destroy(cl, first);
    class_destroy(cl);
    unregister_chrdev_region(first, 1);
    printk(KERN_INFO "RTC ETHCAT_DRIVER: Unregistered\n");
    /*****************************************************************************/
}

/*****************************************************************************/
MODULE_LICENSE("GPL");
MODULE_AUTHOR("LPM rev31");
MODULE_DESCRIPTION("EtherCAT minimal test environment");

module_init(init_mini_module);
module_exit(cleanup_mini_module);
/*****************************************************************************/
